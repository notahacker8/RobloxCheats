#!/bin/bash
ROBLOX_CHEATS_PATH=./RobloxCheats
for (( ; ; ))
do
    $ROBLOX_CHEATS_PATH blox_fruits_chest_farm
    sleep 3
done
